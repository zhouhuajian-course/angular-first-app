import {Pipe, PipeTransform} from '@angular/core';

export class ReversePipe implements PipeTransform {
  transform(value: string): string {
    return '';
  }
}
